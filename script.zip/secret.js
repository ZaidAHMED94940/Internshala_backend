let id = "whereyouat12am@gmail.com";
let pass = "internshala990#";
module.exports = { id, pass };