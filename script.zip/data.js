module.exports = [
    {
        "College": "Jaypee University Of Information Technology",
        "Degree": "Bachelor of Technology (B.Tech)",
        "Stream": "Computer Science and Engineering",
        "Percentage": "85",
        "Training": "Data Structures and Algorithms, Web Development",
        "Organization": "Udemy.com.",
        "description": "Udemy is a great platform where I got to learn the not only the basics of data structures and algorithms but I also got familiar with Web Development and Competitive Programming. Here, the main focus is on concept building and it was a great start for me.",
        "link": "https://github.com/xyz/Task1",
        "hiringReason": "Over the past few years, I have acquired relevant skills and experience, which I shall bring to your organization. I have also worked tirelessly on my communication abilities and teamwork skills, which I will put to use in my future career, which would be in your organization if I am selected for the position.",
        "availability": "Yes, I will be available",
        "rating": "4",
    }
]